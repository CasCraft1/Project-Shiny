library(shiny)
library(budgethelp)
library(openxlsx)
requiredlibraries()
# Define the UI
defaultprojects <- activeprojects()
projectnames <- lapply(defaultprojects[[1]],function(i) {gsub("_"," ",i) })



ui <- navbarPage("",
                 tabPanel("Settings",fluidRow(column(5,textInput("budgetpath","Budget Path"),
                                                     textInput("payrollpath","Payroll Path"),
                                                     textInput("costspath","Other Costs Path"),
                                                     textInput("monthyear","Date (As on Budget Sheet)")),
                                              column(5,checkboxGroupInput("projects","Select Projects",choiceNames=projectnames,choiceValues = defaultprojects[[1]]),checkboxInput("selectall","Select All"))),
                          fluidRow(column(5,textInput("additionalprojects","Additional Projects (As On Budget Sheet)"),actionButton("testbutton","Run!"),textOutput("errormessage")))),
                 tabPanel("Output", uiOutput("newstuff"))
                 
                 
)

